package HotelManagementSystem;

public interface IAdmin {

  public void admin(String Username,String Password);

}
