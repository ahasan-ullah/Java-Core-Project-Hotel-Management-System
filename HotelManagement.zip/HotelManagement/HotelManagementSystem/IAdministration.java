package HotelManagementSystem;

public interface IAdministration {

  public void administration(String Username,String Password);

}
